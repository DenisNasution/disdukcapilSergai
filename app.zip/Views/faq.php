<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>   

    <div class="container main-content">
      <div class="page-banner">
        <h1><i class="fas fa-question-circle"></i> FAQ</h1>
        <p>Pertanyaan yang Sering Diajukan Seputar Pelayanan Adminduk</p>
      </div>

      <div class="breadcrumbs">
        <a href="<?= base_url('index') ?>">Beranda</a> / <span>FAQ</span>
      </div>

      <div class="page-intro">
        <h3>
          <i class="fas fa-comments" style="color: var(--primary-green)"></i>
          Temukan Jawaban Anda Di Sini
        </h3>
        <p>
          Berikut adalah kumpulan pertanyaan yang sering ditanyakan oleh
          masyarakat. Jika Anda tidak menemukan jawaban yang Anda cari, silakan
          hubungi kami melalui kontak yang tersedia.
        </p>
      </div>

      <div class="faq-container">
        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>Apa saja persyaratan untuk mengurus KTP Elektronik?</h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>Persyaratan utama untuk membuat KTP Elektronik adalah:</p>
            <ol>
              <li>Kartu Keluarga (KK) asli.</li>
              <li>Surat pengantar dari RT/RW (jika diperlukan).</li>
              <li>
                Pas foto terbaru (jika tidak memiliki fasilitas foto di kantor).
              </li>
              <li>
                Datang langsung ke kantor Dinas Kependudukan dan Pencatatan
                Sipil terdekat.
              </li>
            </ol>
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>Berapa biaya pengurusan dokumen kependudukan?</h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Berdasarkan Peraturan Pemerintah (PP) Nomor 12 Tahun 2019,
              <strong
                >seluruh pelayanan administrasi kependudukan tidak dipungut
                biaya (GRATIS)</strong
              >. Jika ada pihak yang meminta biaya, laporkan segera melalui
              saluran pengaduan resmi kami.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>
              Saya tidak memiliki data kependudukan sama sekali, apa yang harus
              saya lakukan?
            </h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Penduduk wajib hadir ke kantor Disdukcapil di kantor Jl. Ambon
              Nomor 1B untuk dilakukan pengecekan biometrik. Penduduk membawa
              formulir biodata dan surat pernyataan yang ditandatangani oleh
              keluarga atau penjamin serta aparat kewilayahan setempat. Penduduk
              membawa formulir biodata dan surat pernyataan yang ditandatangani
              oleh keluarga atau penjamin serta aparat kewilayahan setempat.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>Berapa lama proses pembuatan KTP Elektronik?</h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Proses pembuatan KTP Elektronik biasanya memakan waktu
              <strong>maksimal 7 hari kerja</strong> setelah seluruh persyaratan
              lengkap dan data diverifikasi. Kami akan mengirimkan SMS
              pemberitahuan jika KTP sudah selesai dicetak dan siap diambil.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>
              Bagaimana cara mengurus akta kelahiran untuk bayi baru lahir?
            </h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Pengurusan Akta Kelahiran untuk bayi baru lahir bisa dilakukan
              dengan membawa:
            </p>
            <ol>
              <li>Surat Keterangan Lahir dari Rumah Sakit / Bidan.</li>
              <li>Fotokopi KTP kedua orang tua.</li>
              <li>Fotokopi Kartu Keluarga (KK) orang tua.</li>
              <li>Surat nikah orang tua (jika sudah menikah).</li>
            </ol>
            <p>
              Jika belum memiliki KK, kami dapat langsung menerbitkan KK
              sekaligus Akta Kelahiran.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>Apakah pengurusan dokumen bisa dilakukan secara online?</h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Saat ini, layanan hanya dapat dilakukan secara offline atau datang
              langsung ke kantor disdukcapil.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>
              Kenapa dokumen yang kami terima saat ini blangkonya berbeda, hanya
              kertas putih saja?
            </h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Sesuai dengan ketentuan Permendagri Nomor 109 Tahun 2019 tentang
              Formulir dan Buku Yang Digunakan Dalam Administrasi Kependudukan,
              mulai Tahun 2020 dokumen kependudukan Kartu Keluarga, Akte
              Kelahiran, dan Akte Kematian menggunakan kertas HVS ukuran A4 80
              gram.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>
              Kartu Keluarga saya masih belum ber-barcode apakah saya wajib buat
              KK yang ber-barcode?
            </h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Pengajuan Kartu Keluarga hanya dilakukan jika terjadi perubahan
              elemen data. Selama tidak ada perubahan data, maka Kartu Keluarga
              lama tetap berlaku.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" onclick="toggleFaq(this)">
            <h4>Apakah dalam satu rumah boleh lebih dari satu KK?</h4>
            <i class="fas fa-chevron-down faq-icon"></i>
          </div>
          <div class="faq-answer">
            <p>
              Diperbolehkan selama ada kepala keluarga yang sudah berusia di
              atas 17 tahun atau sudah/pernah menikah.
            </p>
          </div>
        </div>
      </div>
    </div>

   
    <?= $this->endSection() ?>