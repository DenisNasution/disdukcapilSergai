<?php

namespace App\Controllers;

use App\Models\QnaModel;

class Qna extends BaseController
{
    protected $qnaModel;

    public function __construct()
    {
        helper('text');
        $this->qnaModel = new QnaModel();
    }

    public function index()
    {
        $data['qna'] = $this->qnaModel->getAnswered();
        $data['title'] = 'Tanya Jawab - Disdukcapil Sergai';
        return view('qna', $data);
    }

    public function submit()
    {
        $rules = [
            'qna_name'      => 'required|min_length[3]|max_length[100]',
            'qna_id_number' => 'required|min_length[5]|max_length[50]|alpha_numeric',
            'qna_question'  => 'required|min_length[10]|max_length[1000]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->qnaModel->insert([
            'qna_id'   => $this->qnaModel->generateId(),
            'qna_name'      => $this->request->getPost('qna_name'),
            'qna_id_number' => $this->request->getPost('qna_id_number'),
            'qna_question'  => $this->request->getPost('qna_question'),
            'qna_status'    => 'pending'
        ]);


        return redirect()->to('/tanya-jawab')->with('success', 'Pertanyaan Anda berhasil dikirim. Silakan tunggu jawaban dari petugas kami.');
    }
}

